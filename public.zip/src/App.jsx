import React, { useState, useEffect } from 'react';
import { Auth, Amplify } from 'aws-amplify';
import AuthConfig from './config/AuthConfig'; // Adjust the path if needed
import { useNavigate } from 'react-router-dom';
import Router from './router';
import { RecoilRoot } from 'recoil';
import UserContext from './Context/UserContext';

Amplify.configure(AuthConfig); // Configure AWS Amplify

function App() {
  const navigate = useNavigate();

  const [userState, setUserState] = useState({
    fetchNewData: false,
    successfullyFetchedDetails: false,
    currentPage: '/login', // Redirect to login initially
  });

  useEffect(() => {
    window.localStorage.setItem('currentPage', window.location.pathname);
    updateCurrentUser();
  }, []);

  const updateCurrentUser = async () => {
    try {
      const user = await Auth.currentAuthenticatedUser({ bypassCache: true });
      if (user) {
        setUserState({
          ...userState,
          userDetails: await user,
        });
        navigate('/'); // Redirect to Dashboard after login
      }
    } catch (err) {
      console.log(' >>> error', err);
      // If not authenticated, stay on login page
      navigate('/login');
    }
  };

  return (
    <UserContext.Provider
      value={{
        userDetails: userState?.userDetails,
        userState,
        setUserState,
        updateCurrentUser,
      }}
    >
      <div className="min-h-screen bg-dark-navy flex flex-col">
        <RecoilRoot>
          <Router />
        </RecoilRoot>
      </div>
    </UserContext.Provider>
  );
}

export default App;
