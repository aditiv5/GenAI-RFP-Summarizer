let uri = 'https://dkgqm8d3sc8l1.cloudfront.net';
 
if (window.location.href.includes('localhost')) {
  uri = 'http://localhost:5173/';
}

const AuthConfig = {
  Auth: {
    identityPoolId: 'ap-south-1:852b3e63-e23e-48bd-9ebf-a7fba4be788a',
    region: 'ap-south-1',
    userPoolId: 'ap-south-1_ZJqyRUTlW',
    userPoolWebClientId: 'asc4njk8gjop7ccr192ke6gri',
  },
  oauth: {
    domain: 'demos-cloudthat.auth.ap-south-1.amazoncognito.com',
    scope: ['phone', 'email', 'profile', 'openid', 'aws.cognito.signin.user.admin'],
    redirectSignIn: uri,
    redirectSignOut: uri,
    responseType: 'token',
  },
};

export default AuthConfig;
